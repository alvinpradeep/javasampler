package com.jmeter.javasamplers.example;

import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.threads.JMeterContextService;
import org.apache.jmeter.config.Arguments;
import java.io.*;

/**
 * The javaSampler class custom java sampler for jmeter.
 *
 * @Author Alvin
 * @Version 1.0
 * @since 10/05/2018
 */
public class javaSampler extends AbstractJavaSamplerClient {
    FileInputStream fin= null;
    BufferedReader br=null;
    //kafka producer
   // private SolaceProducer<String, Object> producer;
    //Message placeholder key
    private String placeHolder;
    // topic on which messages will be sent
    private String topic;

    /**
     * Gets invoked exactly once  before thread starts
     *
     * @param context
     */
    @Override
    public void setupTest(JavaSamplerContext context) {
        super.setupTest(context);
        try {
            fin = new FileInputStream("C:\\Users\\10640108\\Downloads\\samples.fix.txt");
             br=new BufferedReader(new InputStreamReader(fin));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public Arguments getDefaultParameters() {

        Arguments arguments = new Arguments();
        arguments.addArgument("fixmsg","${__StringFromFile(C:\\Users\\10640108\\Downloads\\samples.fix.txt,,,)}"  );
        return  arguments;
    }





        public SampleResult runTest(JavaSamplerContext javaSamplerContext) {

        final SampleResult sampleResult = new SampleResult();

        sampleResult.sampleStart();
        Object message = JMeterContextService.getContext().getVariables().get("udvmsg");

            String fixmsg = javaSamplerContext.getParameter("fixmsg");
            System.out.println(message.toString());
        try {

            //String line = Read_one_Line(br);
//            System.out.println(Read_one_Line(br));
//            System.out.println(Read_one_Line(br));
//            System.out.println(Read_one_Line(br));
            // do some work
            //Thread.sleep(100);

            sampleResult.setResponseMessage(fixmsg);
            sampleResult.setSuccessful(true);




        } catch (Exception e) {
            // nop
        } finally {
            sampleResult.sampleEnd();
        }

        return sampleResult;
    }

    public static String Read_one_Line(final BufferedReader br) throws IOException
    {
        String next_line=br.readLine();

        return next_line;
    }
}
