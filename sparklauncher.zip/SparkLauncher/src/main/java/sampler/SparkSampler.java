package sampler;

import org.apache.spark.launcher.SparkAppHandle;
import org.apache.spark.launcher.SparkLauncher;

public class SparkSampler {
  public static void main(String[] args) throws Exception {
//    SparkAppHandle handle = new SparkLauncher()
//    	 .setSparkHome(sparkHome)
//    	 .set
//      .setAppResource("/my/app.jar")
//      .setMainClass("my.spark.app.Main")
//      .setMaster("local")
//      .setConf(SparkLauncher.DRIVER_MEMORY, "2g")
//      .startApplication();
    // Use handle API to monitor / control application.
	  
	  
	  SparkAppHandle handle = new SparkLauncher()
		  .setSparkHome("/opt/cloudera/parcels/SPARK2/lib/spark2/")
			    .setAppResource("<your_main_app_jar>")
			    .setDeployMode("cluster")
			    .addSparkArg("--master", "yarn")
			    .setConf(SparkLauncher.DRIVER_MEMORY, "")
	            .setConf(SparkLauncher.EXECUTOR_MEMORY, "")
	            .setConf(SparkLauncher.EXECUTOR_CORES, "" + "")
	            .setConf(SparkLauncher.CHILD_PROCESS_LOGGER_NAME, "appName")
			    .setMainClass("<your_main_class>")
//			    .addJar("<additional_jar>")
//			    .addFile("<resource_file>")
			    .addAppArgs("<args_to_your_app>")
			    .startApplication();
  }
  
  
}

